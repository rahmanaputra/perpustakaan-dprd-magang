@extends('layouts/app')

@section('content')
    <livewire:peminjam.keranjang></livewire:peminjam.keranjang>
@endsection