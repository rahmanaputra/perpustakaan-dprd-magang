<!-- ChartJS -->
<script src="/adminlte/plugins/chart.js/Chart.min.js"></script>