<footer class="main-footer">
    <div class="row justify-content-center">
      <strong>Copyright &copy; Musyahya 2021</strong>
    </div>
</footer>