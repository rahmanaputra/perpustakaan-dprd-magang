@extends('admin-lte/app')
@section('title', 'Kategori')
@section('active-kategori', 'active')
@section('active-data-master', 'active')

@section('content')
    <livewire:petugas.kategori></livewire:petugas.kategori>
@endsection