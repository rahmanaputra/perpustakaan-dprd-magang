@extends('admin-lte/app')
@section('title', 'Transaksi')
@section('active-transaksi', 'active')

@section('content')
    <livewire:petugas.transaksi></livewire:petugas.transaksi>
@endsection