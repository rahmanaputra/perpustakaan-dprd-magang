@extends('admin-lte/app')
@section('title', 'Penerbit')
@section('active-penerbit', 'active')
@section('active-data-master', 'active')

@section('content')
    <livewire:petugas.penerbit></livewire:petugas.penerbit>
@endsection