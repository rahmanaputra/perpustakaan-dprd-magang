@extends('admin-lte/app')
@section('title', 'Buku')
@section('active-buku', 'active')
@section('active-data-master', 'active')

@section('content')
    <livewire:petugas.buku></livewire:petugas.buku>
@endsection